This is the heuristic we programmed:

